#include "../inc/libmx.h"

char *mx_strndup(const char *s1, size_t n) {
    if (s1 == NULL)
        return NULL;
    size_t length = mx_strlen(s1);
    if (n < length)
        return mx_strncpy(mx_strnew(mx_strlen(s1)), s1, n);
    return mx_strncpy(mx_strnew(mx_strlen(s1)), s1, length);
}

