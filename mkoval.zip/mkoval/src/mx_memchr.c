#include "../inc/libmx.h"

void *mx_memchr(const void *s, int c, size_t n) {
    const char *ptr = s;
    for (size_t i = 0; i < n; i++) {
        if (ptr[i] == (char)c)
            return (char*)s + i;
    }
    return NULL;
}

