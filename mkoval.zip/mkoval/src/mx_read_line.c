#include "../inc/libmx.h"

int mx_read_line(char **lineptr, size_t buf_size, char delim, const int fd) {
    if (fd < 0)
        return -2;
    if (buf_size <= 0)
        return -2;
    char buffer[buf_size];
    int read_bytes = 0;
    int count_bytes = 0;
    int all = 0;
    while((count_bytes = read(fd, buffer, buf_size)) > 0) {
        for (int i = 0; i < count_bytes; i++) {
            if (buffer[i] == delim) {
                read_bytes += i;
                return read_bytes;
            }
            (*lineptr)[all] = buffer[i];
            all++;
        }
        read_bytes += count_bytes;
    }
    if (read_bytes == 0)
        return -1;
    return read_bytes;
}

