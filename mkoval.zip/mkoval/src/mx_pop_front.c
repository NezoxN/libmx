#include "../inc/libmx.h"

void mx_pop_front(t_list **head) {
    if (*head == NULL)
        return;
    t_list *pop_start_node = *head;
    *head = pop_start_node->next;
    free(pop_start_node);
    pop_start_node = NULL;
}

