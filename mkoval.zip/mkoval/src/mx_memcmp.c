#include "../inc/libmx.h"

int mx_memcmp(const void *s1, const void *s2, size_t n) {
    const char *ptr_d = s1;
    const char *ptr_s = s2;
    for (size_t i = 0; i < n; i++) {
        if (ptr_d[i] > ptr_s[i] || ptr_d[i] < ptr_s[i])
            return ptr_d[i] - ptr_s[i];
        if (ptr_d[i] == '\0' || ptr_s[i] == '\0')
            break;
    }
    return 0;
}

