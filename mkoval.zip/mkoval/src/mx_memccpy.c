#include "../inc/libmx.h"

void *mx_memccpy(void *restrict dst, const void *restrict src, int c, size_t n) {
    char *ptr_d = dst;
    const char *ptr_s = src;
    for (int i = 0; i < (int)n; i++) {
        ptr_d[i] = ptr_s[i];
        if (ptr_s[i] == (char)c)
        {
            return ptr_d + i;
        }
    }
    return NULL;
}

