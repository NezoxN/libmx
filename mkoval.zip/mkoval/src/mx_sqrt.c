#include "../inc/libmx.h"

int mx_sqrt(int x) {
    float tmp;
    float sqrt;
    
    if (x < 0)
        return 0;
    sqrt = x / 2;
    tmp = 0;
    while (sqrt != tmp) {
        tmp = sqrt;
        sqrt = x / tmp + tmp;
        sqrt /= 2;
    }
    x = sqrt;
    if (x != sqrt)
        return 0;
    return x;
}

