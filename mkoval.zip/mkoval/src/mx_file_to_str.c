#include "../inc/libmx.h"

char *mx_file_to_str(const char *filename) {
    int fd = open(filename, O_RDONLY);
    if (fd == -1) {
        return NULL;
    }
    char print_arr;
    int size = 0;
    int tmp = read(fd, &print_arr, 1);
    while (tmp) {
        tmp = read(fd, &print_arr, 1);
        size++;
    }
    close(fd);
    
    char s[size];
    fd = open(filename, O_RDONLY);
    read(fd, s, size);
    close(fd);
    char *result = mx_strdup(s);
    return result;
}

