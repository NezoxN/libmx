#include "../inc/libmx.h"

char *mx_strcat(char *s1, const char *s2) {
    int index = mx_strlen(s1);
    for(int i = 0; index < mx_strlen(s1) + mx_strlen(s2); i++) {
        s1[index] = s2[i];
        index++;
    }
    return s1;
}

