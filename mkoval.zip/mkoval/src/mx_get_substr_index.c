#include "../inc/libmx.h"

int mx_get_substr_index(const char *str, const char *sub) {
	int i;
	if (str == NULL || sub == NULL)
		return -2;
	for (i = 0; str[i] != '\0'; i++) {
		if (str[i] == sub[0]) {
			int tmp = i;
			for (int j = 1; sub[j] != '\0'; j++) {
				tmp++;
				if (str[tmp] != sub[j]) {
					return -1;
				}
			}
			return i;
		}
	}
	return -1;
}

