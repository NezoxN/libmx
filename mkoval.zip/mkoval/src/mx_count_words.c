#include "../inc/libmx.h"

int mx_count_words(const char *str, char delimiter) {
    bool word = false;
    int count = 1;
    for (int i = 0; str[i] != '\0'; i++) {
        if (str[0] == delimiter && i == 0) {
            count--;
        }
        if (str[i] == delimiter) {
            if (str[i + 1] != delimiter && str[i + 1] != '\0') {
                word = true;
            }
        }
        if (word == true && str[i] == delimiter) {
            count++;
            word = false;
        }
    }
    return count;
}

