#include "../inc/libmx.h"

void mx_str_reverse(char *s) {
    int num_character = mx_strlen(s);
    int i2 = mx_strlen(s);
    for (int i = 0; i < num_character / 2; i++) {
        mx_swap_char(&s[i], &s[i2 - 1]);
        i2--;
    }
}

