#include "../inc/libmx.h"

char *mx_strjoin(char const *s1, char const *s2) {
    if (s1 == NULL && s2 == NULL)
       return NULL;
    else if (s1 == NULL) {
        char *s2_tmp = mx_strdup(s2);
        return s2_tmp;
    }
    else if (s2 == NULL) {
        char *s1_tmp = mx_strdup(s1);
        return s1_tmp;
    }
    else {
        char *s1_tmp = mx_strdup(s1);
        char *s2_tmp = mx_strdup(s2);
        return mx_strdup(mx_strcat(s1_tmp, s2_tmp));
    }
}

