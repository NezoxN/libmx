#include "../inc/libmx.h"

char *mx_replace_substr(const char *str, const char *sub, const char *replace) {
	int subcount = 0;
    const char* tmp = str;
    while ((tmp = mx_strstr(tmp, sub)) != NULL) {
        subcount++;
        tmp += mx_strlen(sub);
    }
	int all = 0;
	int length = mx_strlen(str) + (mx_strlen(replace) - mx_strlen(sub)) * subcount;
	char* result = (char*)malloc((length + 1) * 4);
	for (int i = 0; str[i] != '\0';) {
		if (mx_strncmp(str + i, sub, mx_strlen(sub)) == 0) {
			mx_strcpy(result + i, replace);
			i += mx_strlen(sub);
			all += mx_strlen(replace);
		} else {
			result[all] = str[i];
			all++;
			i++;
		}
	}
	return result;
}

