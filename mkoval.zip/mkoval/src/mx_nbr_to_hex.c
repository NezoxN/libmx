#include "../inc/libmx.h"

char *mx_nbr_to_hex(unsigned long nbr) {
    long nbr_check = nbr;
    if (nbr_check < 0  || nbr > 4294967295)
        return 0;
    int tmp;
    char hex_number_tmp[100];
    int all = 0;
    while (nbr != 0) {
	tmp = nbr % 16;
	nbr /= 16;
        if (tmp < 10) {
	    hex_number_tmp[all] = tmp + 48;
        } else if (tmp >= 10 && tmp <= 16) {
	    hex_number_tmp[all] = tmp + 87;
        }
        all++;
    }
    char *hex_number = (char*)malloc(all);
    int i = 0;
    for (int j = all - 1; j >= 0; j--) {
        hex_number[i] = hex_number_tmp[j];
        i++;
    }
    return hex_number;
}

