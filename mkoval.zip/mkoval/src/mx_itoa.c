#include "../inc/libmx.h"

char *mx_itoa(int number) {
    int temp = number;
    int length = 0;

    if (number < 0)
        length++;
    if (number == 0) {
        char *result = (char*)malloc(2);
        result[0] = '0';
        result[1] = '\0';
        return result;
    }
    while (temp != 0) {
        temp /= 10;
        length++;
    }

    char *result = (char*)malloc(length + 1);

    if (number < 0) {
        result[0] = '-';
        number = -number;
    }
    result[length] = '\0';
    while (number != 0) {
        length--;
        result[length] = 48 + (number % 10);
        number /= 10;
    }
    return result;
}

