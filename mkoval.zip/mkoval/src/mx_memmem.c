#include "../inc/libmx.h"

void *mx_memmem(const void *big, size_t big_len, const void *little, size_t little_len) {
    const char *ptr_b = big;
    const char *ptr_l = little;
    int val;
    ptr_b = mx_memchr(ptr_b, ptr_l[0], big_len);
    if (ptr_b == 0)
        return NULL;
    val = mx_memcmp(ptr_b, ptr_l, little_len);
    if (val == 0) {
        return (char*)ptr_b;
    }
    else {
        return NULL;
    }
}

