#include "../inc/libmx.h"

int mx_quicksort(char **arr, int left, int right) {
    int count_swap = 0;
    if (left < right) {
        char *pivot = arr[(left + right) / 2];
        int high = left;
        int low = right;
    
        while (high <= low) {
            while (mx_strlen(arr[high]) < mx_strlen(pivot))
                high++;
            while (mx_strlen(arr[low]) > mx_strlen(pivot))
                low--;
            if (arr[high] != arr[low] && mx_strlen(arr[low]) != mx_strlen(arr[high])) {
                char* tmp = arr[high];
                arr[high] = arr[low];
                arr[low] = tmp;
                count_swap++;     
            }
            high++;
            low--;
        }
        count_swap += mx_quicksort(arr, left, low);
        count_swap += mx_quicksort(arr, high, right);
    }
    return count_swap;
}

