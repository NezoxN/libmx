#include "../inc/libmx.h"

char *mx_strstr(const char *haystack, const char *needle) {
    int val;
    haystack = mx_strchr(haystack, needle[0]);
    if (haystack == 0)
        return NULL;
    val = mx_strncmp(haystack, needle, mx_strlen(needle));
    if (val == 0) {
        return (char*)haystack;
    }
    else {
        return NULL;
    }
}

