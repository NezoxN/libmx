#include "../inc/libmx.h"

unsigned long mx_hex_to_nbr(const char *hex) {
    unsigned long result = 0;
    for (int i = 0; hex[i] != '\0'; i++) {
	if (hex[i] >= 48 && hex[i] <= 57)
            result = result * 16 + (hex[i] - 48);
        else if (hex[i] >= 97 && hex[i] <= 122)
            result = result * 16 + (hex[i] - 87);
        else if (hex[i] >= 65 && hex[i] <= 90)
            result = result * 16 + (hex[i] - 55);
        else
            return 0;
    }
    return result;
}

