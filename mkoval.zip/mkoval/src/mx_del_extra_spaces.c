#include "../inc/libmx.h"

char *mx_del_extra_spaces(const char *str) {
    bool del_space = false;
    if (str == NULL)
        return NULL;
    char *tmp = mx_strtrim(str);
    char *result_tmp = mx_strnew(mx_strlen(tmp));
    int i = 0;
    for (int all = 0; tmp[all] != '\0'; all++) {
        while (mx_isspace(tmp[all]) == true) {
            all++;
            del_space = true;
        }
        if (del_space == true) {
            result_tmp[i] = ' ';
            del_space = false;
            i++;
        }
	   result_tmp[i] = tmp[all];
	   i++;
    }
    char *result = mx_strnew(mx_strlen(result_tmp));
    mx_strncpy(result, result_tmp, i);
    mx_strdel(&tmp);
    mx_strdel(&result_tmp);
    return result;
}

