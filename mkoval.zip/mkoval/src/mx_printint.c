#include "../inc/libmx.h"

void mx_printint(int n) {
    int tmp_n = n;
    int all_digit = 0;
    if (n < 0) {
        mx_printchar('-');
        n = -n;
    }
    if (n == 0)
        mx_printchar('0');
    while (tmp_n != 0) {
	tmp_n /= 10;
	all_digit++;
    }
    int digit[all_digit];
    for (int i = 0; i < all_digit; i++) {
        digit[i] = n % 10 + 48;
        n /= 10;
    }
    for (int i = all_digit - 1; i > -1; i--)
    	mx_printchar(digit[i]);
}

