#include "../inc/libmx.h"

t_list *mx_sort_list(t_list *list, bool (*cmp)(void *a, void *b)) {
    if (list == NULL || cmp == NULL)
        return NULL;
    bool sort = true;
    while (sort == true) {
        sort = false;
        for (t_list *all = list; all->next != NULL; all = all->next) {
            if(cmp(all->data, all->next->data) == true) {
                void *tmp = all->data;
                all->data = all->next->data;
                all->next->data = tmp;
                sort = true;
            }
        }
    }
    return list;
}

