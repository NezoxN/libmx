#include "../inc/libmx.h"

int mx_bubble_sort(char **arr, int size) {
    int counter = 0;
    bool sort = true;
    while (sort == true) {
        sort = false;
        for (int i = 1; i < size; i++) {
            if (mx_strcmp(arr[i], arr[i - 1]) < 0) {
                char *tmp = arr[i - 1];
                arr[i - 1] = arr[i];
                arr[i] = tmp;
		counter++;
		sort = true;
            }
        }
    }
    return counter;
}

