#include "../inc/libmx.h"

char *mx_strtrim(const char *str) {
    if (str == NULL)
        return NULL;
    char *tmp = mx_strnew(mx_strlen(str));
    int last_character = mx_strlen(str);
    int space_front = 0;
    while (mx_isspace(str[space_front]) == true)
	   space_front++;
    int i = 0;
    for (int all = space_front; str[all] != '\0'; all++) {
	   tmp[i] = str[all];
	   i++;
    }
    for (int j = i - 1; mx_isspace(tmp[j]) == true; j--)
        last_character = j;
    char *result_tmp = mx_strnew(mx_strlen(tmp));
    mx_strncpy(result_tmp, tmp, last_character);
    mx_strdel(&tmp);
    char *result = mx_strnew(mx_strlen(result_tmp));
    mx_strncpy(result, result_tmp, last_character);
    mx_strdel(&result_tmp);
    return result;
}

