#include "../inc/libmx.h"

void *mx_memmove(void *dst, const void *src, size_t len) {
    char *ptr_d = dst;
    const char *ptr_s = src;
    char *tmp = (char*)malloc(len);
    for (size_t i = 0; i < len; i++)  
        tmp[i] = ptr_s[i];  
    for (size_t i = 0; i < len; i++)  
        ptr_d[i] = tmp[i];
    free(tmp); 
    return dst;
}

