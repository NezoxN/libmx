#include "../inc/libmx.h"

char **mx_strsplit(char const *s, char c) {
    if (s == NULL)
        return NULL;
    char** result = (char**)malloc((mx_count_words(s, c) + 1) * sizeof(char*));
    int all = 0;
    int num = 0;
    bool word = false;
    int start = all;
    int end = all;
    while (num < mx_count_words(s, c)) {
        if (s[all] != c) {
            start = all;
            while (s[all] != c && s[all] != '\0')
                all++;
            word = true;
        }
        end = all;
        all++;
        if (word == true) {
            int range = end - start;
            result[num] = mx_strndup(s + start, range);
            num++;
            word = false;
        }
        
    }
    result[num] = NULL;
    return result;
}

